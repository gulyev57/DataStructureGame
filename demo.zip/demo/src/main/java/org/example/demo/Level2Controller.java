package org.example.demo;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Level2Controller {

    @FXML private FlowPane boardPane;
    @FXML private Label scoreLabel;
    @FXML private Label diceLabel;
    @FXML private Label ladderTrapLabel;

    private DoublyNode<String> head;
    private DoublyNode<String> playerTile;
    private List<Button> spotButtons = new ArrayList<>();
    private int score = 0;
    private int counter = 0;
    private Random random = new Random();
    private boolean gameEnded = false;

    private Image treasureImage;
    private Image trapImage;
    private Image emptyImage;
    private Image playerImage;

    @FXML
    public void initialize() {
        treasureImage = new Image(getClass().getResourceAsStream("/images/chest2.png"));
        trapImage = new Image(getClass().getResourceAsStream("/images/trap.png"));
        emptyImage = new Image(getClass().getResourceAsStream("/images/empty.png"));
        playerImage = new Image(getClass().getResourceAsStream("/images/player.png"));

        generateBoard();
        playerTile = head;
        renderBoard();
        highlightPlayer();
    }

    private void generateBoard() {
        head = new DoublyNode<>(randomType());
        DoublyNode<String> current = head;
        for (int i = 1; i < 30; i++) {
            DoublyNode<String> newNode = new DoublyNode<>(randomType());
            current.next = newNode;
            newNode.prev = current;
            current = newNode;
        }
    }

    private String randomType() {
        int r = random.nextInt(5);
        return switch (r) {
            case 0 -> "Treasure";
            case 1 -> "Trap";
            case 2 -> "Forward";
            case 3 -> "Backward";
            default -> "Empty";
        };
    }

    private void renderBoard() {
        boardPane.getChildren().clear();
        spotButtons.clear();
        DoublyNode<String> temp = head;
        while (temp != null) {
            Button spotButton = new Button();
            spotButton.setGraphic(getTileView(temp.data));
            spotButton.setPrefSize(64, 64);
            spotButton.setStyle("-fx-background-color: transparent;");
            spotButtons.add(spotButton);
            boardPane.getChildren().add(spotButton);
            temp = temp.next;
        }
    }

    private ImageView getTileView(String type) {
        ImageView view;
        switch (type) {
            case "Treasure" -> {
                view = new ImageView(treasureImage);
                view.setViewport(new Rectangle2D(0, 0, 32, 32));
            }
            case "Trap" -> {
                view = new ImageView(trapImage);
                view.setViewport(new Rectangle2D(0, 0, 32, 32));
            }
            default -> view = new ImageView(emptyImage);
        }
        view.setFitWidth(32);
        view.setFitHeight(32);
        return view;
    }

    private void highlightPlayer() {
        for (int i = 0; i < spotButtons.size(); i++) {
            DoublyNode<String> node = getNodeAtIndex(i);
            spotButtons.get(i).setGraphic(getTileView(node.data));
        }

        int playerIndex = getPlayerIndex();
        if (playerIndex != -1) {
            ImageView view = new ImageView(playerImage);
            view.setFitWidth(32);
            view.setFitHeight(32);
            spotButtons.get(playerIndex).setGraphic(view);
        }
    }

    private DoublyNode<String> getNodeAtIndex(int index) {
        DoublyNode<String> temp = head;
        for (int i = 0; i < index; i++) {
            if (temp != null) temp = temp.next;
        }
        return temp;
    }

    private int getPlayerIndex() {
        DoublyNode<String> temp = head;
        int index = 0;
        while (temp != null) {
            if (temp == playerTile) return index;
            temp = temp.next;
            index++;
        }
        return -1;
    }

    @FXML
    private void rollDice() {
        if (playerTile == null || counter >= 30) {
            gameEnded = true;
            Platform.runLater(() -> endGame());  // SAFETY FIX!
            return;
        }
        if (gameEnded) return;

        Timeline timeline = new Timeline();
        for (int i = 0; i < 10; i++) {
            int tempRoll = random.nextInt(6) + 1;
            timeline.getKeyFrames().add(new KeyFrame(Duration.millis(100 * i), e -> {
                diceLabel.setText("Rolling... " + tempRoll);
            }));
        }

        timeline.setOnFinished(e -> {
            int dice = random.nextInt(6) + 1;
            counter += dice;
            diceLabel.setText("Dice: " + dice);
            movePlayer(dice);
            highlightPlayer();
            scoreLabel.setText("Score: " + score);
            if (playerTile == null || counter >= 30) {
                gameEnded = true;
                Platform.runLater(() -> endGame());  // SAFETY FIX!
            }
        });

        timeline.play();
    }

    private void movePlayer(int steps) {
        for (int i = 0; i < steps; i++) {
            if (playerTile != null) playerTile = playerTile.next;
        }

        if (playerTile != null) {
            switch (playerTile.data) {
                case "Treasure" -> score += 10;
                case "Trap" -> score -= 5;
                case "Forward" -> {
                    int forwardSteps = random.nextInt(3) + 1;
                    for (int i = 0; i < forwardSteps; i++) {
                        if (playerTile.next != null) playerTile = playerTile.next;
                    }
                    ladderTrapLabel.setText("Ladder: " + forwardSteps + " steps forward!");
                }
                case "Backward" -> {
                    int backwardSteps = random.nextInt(3) + 1;
                    for (int i = 0; i < backwardSteps; i++) {
                        if (playerTile.prev != null) playerTile = playerTile.prev;
                    }
                    ladderTrapLabel.setText("Trap: " + backwardSteps + " steps backward!");
                }
            }
        }
    }

    private void endGame() {
        HelloApplication.player.setScoreLevel2(score);
        HelloApplication.player.saveToFile();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Game Complete");
        alert.setHeaderText("Your final score for Level 2: " + score);
        alert.setContentText("Returning to main menu.");

        Platform.runLater(() -> {
            alert.showAndWait();
            returnToMainMenu();
        });
    }
    private void returnToMainMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/demo/main-menu.fxml"));
            Parent root = loader.load();

            Stage currentStage = (Stage) boardPane.getScene().getWindow();
            currentStage.setScene(new Scene(root));
            currentStage.setTitle("Main Menu");
            currentStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Nested Doubly Linked List node class
    private static class DoublyNode<T> {
        T data;
        DoublyNode<T> next;
        DoublyNode<T> prev;

        DoublyNode(T data) {
            this.data = data;
        }
    }
}