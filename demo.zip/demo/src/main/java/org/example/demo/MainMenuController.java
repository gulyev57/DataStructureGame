package org.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainMenuController {

    @FXML
    private Button startButton; // Optional: bind to the Start Game button
    @FXML
    private TextField usernameField;
    @FXML
    private void startGame() {
        if(usernameField.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please enter a username.");
            alert.showAndWait();
            return;
        } else {
            HelloApplication.player.setName(usernameField.getText());  // Save username for later
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/demo/level1-view.fxml"));
            Parent root = loader.load();

            Stage currentStage = (Stage) startButton.getScene().getWindow();
            currentStage.setScene(new Scene(root));
            currentStage.setTitle("Treasure Hunt - Level 1");
            currentStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void viewScoreboard() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please enter a username.");
            alert.showAndWait();
            return;
        }

        List<String> allScores = new ArrayList<>();
        BSTNode root = null;

        try (BufferedReader reader = new BufferedReader(new FileReader("scores.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("username=" + username)) {
                    // Parse the line
                    String[] parts = line.split(",");
                    for (String part : parts) {
                        if (part.trim().startsWith("level1=")) {
                            int score = Integer.parseInt(part.trim().substring(7));
                            root = insert(root, score, username, "Level 1");
                        }
                        if (part.trim().startsWith("level2=")) {
                            int score = Integer.parseInt(part.trim().substring(7));
                            root = insert(root, score, username, "Level 2");
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (root == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No scores found for " + username);
            alert.showAndWait();
            return;
        }

        collectScores(root, allScores);

        BSTNode best = findMax(root);
        BSTNode worst = findMin(root);

        StringBuilder sb = new StringBuilder();
        sb.append("All Scores: ").append(String.join(", ", allScores)).append("\n");
        sb.append("Best Score: ").append(best.score).append(" (" + best.level + ")\n");
        sb.append("Worst Score: ").append(worst.score).append(" (" + worst.level + ")");

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Scoreboard");
        alert.setHeaderText("Scores for " + username);
        alert.setContentText(sb.toString());
        alert.showAndWait();
    }

    static class BSTNode {
        int score;
        String username;
        String level;
        BSTNode left, right;

        public BSTNode(int score, String username, String level) {
            this.score = score;
            this.username = username;
            this.level = level;
            this.left = this.right = null;
        }
    }

    private BSTNode insert(BSTNode root, int score, String username, String level) {
        if (root == null) return new BSTNode(score, username, level);
        if (score < root.score) root.left = insert(root.left, score, username, level);
        else root.right = insert(root.right, score, username, level);
        return root;
    }

    private void collectScores(BSTNode node, List<String> scores) {
        if (node == null) return;
        collectScores(node.left, scores);
        scores.add(node.score + " (" + node.level + ")");
        collectScores(node.right, scores);
    }

    private BSTNode findMin(BSTNode node) {
        while (node.left != null) node = node.left;
        return node;
    }

    private BSTNode findMax(BSTNode node) {
        while (node.right != null) node = node.right;
        return node;
    }
}