package org.example.demo;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class Level1Controller {
    int counter = 0;
    @FXML private FlowPane boardPane;
    @FXML private Label scoreLabel;
    @FXML private Label diceLabel;

    private Node<String> head;
    private Node<String> player;
    private List<Button> spotButtons = new ArrayList<>();
    private int score = 0;
    private Random random = new Random();
    private boolean gameEnded = false;

    private Image treasureImage;
    private Image trapImage;
    private Image emptyImage;
    private Image playerImage;

    @FXML
    public void initialize() {
        // Loads images
        treasureImage = new Image(getClass().getResourceAsStream("/images/chest2.png"));
        trapImage = new Image(getClass().getResourceAsStream("/images/trap.png"));
        emptyImage = new Image(getClass().getResourceAsStream("/images/empty.png"));
        playerImage = new Image(getClass().getResourceAsStream("/images/player.png"));

        generateBoard();
        player = head;
        renderBoard();
        highlightPlayer();
    }

    private void generateBoard() {
        head = new Node<>(randomType());
        Node<String> current = head;
        for (int i = 1; i < 30; i++) {
            Node<String> newNode = new Node<>(randomType());
            current.next = newNode;
            current = newNode;
        }
    }

    private String randomType() {
        int r = random.nextInt(3);
        return switch (r) {
            case 0 -> "Treasure";
            case 1 -> "Trap";
            default -> "Empty";
        };
    }

    private void renderBoard() {
        boardPane.getChildren().clear();
        spotButtons.clear();
        Node<String> temp = head;
        while (temp != null) {
            Button spotButton = new Button();
            spotButton.setGraphic(getTileView(temp.data));
            spotButton.setPrefSize(64, 64);
            spotButton.setStyle("-fx-background-color: transparent;");
            spotButtons.add(spotButton);
            boardPane.getChildren().add(spotButton);
            temp = temp.next;
        }
    }

    private ImageView getTileView(String type) {
        ImageView view;
        switch (type) {
            case "Treasure" -> {
                view = new ImageView(treasureImage);
                view.setViewport(new Rectangle2D(0, 0, 32, 32));
            }
            case "Trap" -> {
                view = new ImageView(trapImage);
                view.setViewport(new Rectangle2D(0, 0, 32, 32));
            }
            default -> view = new ImageView(emptyImage);
        }
        view.setFitWidth(32);
        view.setFitHeight(32);
        return view;
    }

    private void highlightPlayer() {
        for (int i = 0; i < spotButtons.size(); i++) {
            Node<String> node = getNodeAtIndex(i);
            spotButtons.get(i).setGraphic(getTileView(node.data));
        }

        int playerIndex = getPlayerIndex();
        if (playerIndex != -1) {
            ImageView view = new ImageView(playerImage);
            view.setFitWidth(32);
            view.setFitHeight(32);
            spotButtons.get(playerIndex).setGraphic(view);
        }
    }

    private Node<String> getNodeAtIndex(int index) {
        Node<String> temp = head;
        for (int i = 0; i < index; i++) {
            if (temp != null) temp = temp.next;
        }
        return temp;
    }

    private int getPlayerIndex() {
        Node<String> temp = head;
        int index = 0;
        while (temp != null) {
            if (temp == player) return index;
            temp = temp.next;
            index++;
        }
        return -1;
    }

    @FXML
    private void rollDice() {
        if (player == null || counter >= 30) {
            gameEnded = true;
            endGame();
        }
        if (gameEnded) return;

        Timeline timeline = new Timeline();
        for (int i = 0; i < 10; i++) {
            int tempRoll = random.nextInt(6) + 1;
            timeline.getKeyFrames().add(new KeyFrame(Duration.millis(100 * i), e -> {
                diceLabel.setText("Rolling... " + tempRoll);
            }));
        }

        timeline.setOnFinished(e -> {
            int dice = random.nextInt(6) + 1;
            counter+= dice;
            diceLabel.setText("Dice: " + dice);
            movePlayer(dice);
            highlightPlayer();
            scoreLabel.setText("Score: " + score);
            if (player == null || counter >= 30) {
                gameEnded = true;
                endGame();
            }
        });

        timeline.play();
    }

    private void movePlayer(int steps) {
        for (int i = 0; i < steps; i++) {
            if (player != null) player = player.next;
        }

        if (player != null) {
            if (player.data.equals("Treasure")) score += 10;
            else if (player.data.equals("Trap")) score -= 5;
        }
    }

    private void endGame() {
        HelloApplication.player.setScoreLevel1(score);

        // Create an alert with two buttons
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Level Complete");
        alert.setHeaderText("Final Score: " + score);
        alert.setContentText("Do you want to proceed to Level 2 or return to the Main Menu?");

        ButtonType level2Button = new ButtonType("Go to Level 2");
        ButtonType mainMenuButton = new ButtonType("Go to Main Menu");

        alert.getButtonTypes().setAll(level2Button, mainMenuButton);

        Platform.runLater(() -> {
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == level2Button) {
                loadLevel2();
            } else {
                returnToMainMenu();
            }
        });
    }
    private void loadLevel2() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/demo/level2-view.fxml"));
            Parent root = loader.load();

            Stage currentStage = (Stage) boardPane.getScene().getWindow();
            currentStage.setScene(new Scene(root));
            currentStage.setTitle("Treasure Hunt - Level 2");
            currentStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void returnToMainMenu() {
        try {
            HelloApplication.player.saveToFile();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/demo/main-menu.fxml"));
            Parent root = loader.load();

            Stage currentStage = (Stage) boardPane.getScene().getWindow();
            currentStage.setScene(new Scene(root));
            currentStage.setTitle("Main Menu");
            currentStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class Node<T> {
        T data;
        Node<T> next;

        Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}