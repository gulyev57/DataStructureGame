package org.example.demo;

import java.io.FileWriter;
import java.io.IOException;

public class Player {
    private String name;
    private int scoreLevel1;
    private int scoreLevel2;
    public Player(String name) {
        this.name = name;
        this.scoreLevel1 = 0;
        this.scoreLevel2 = 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScoreLevel1() {
        return scoreLevel1;
    }

    public void setScoreLevel1(int scoreLevel1) {
        this.scoreLevel1 = scoreLevel1;
    }

    public int getScoreLevel2() {
        return scoreLevel2;
    }

    public void setScoreLevel2(int scoreLevel2) {
        this.scoreLevel2 = scoreLevel2;
    }

    @Override
    public String toString() {
        return "username=" + name + ", level1=" + scoreLevel1 + "level2=" + scoreLevel2;
    }

    public void saveToFile() {
        try (FileWriter writer = new FileWriter("scores.txt", true)) { // true means append mode
            writer.write(this.toString() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
